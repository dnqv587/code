#!/bin/sh  
exe="icc_iec104_server"
des="/home/ubuntu/Documents/IEC104" 
deplist=$(ldd $exe | awk  '{if (match($3,"/")){ printf("%s "),$3 } }')  
cp $deplist $des
